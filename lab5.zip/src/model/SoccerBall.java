package model;

import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

/**
 * The soccer ball
 */
public class SoccerBall
{
	//the ball
	private static final SoccerBall soccerBall = new SoccerBall();
	//the location of the ball
	private Point position;
	//the velocity of the ball
	private double velocity;
	//the color of the ball
	private final Color color;

	/**
	 * Contructor
	 */
	private SoccerBall()
	{
		color = Color.white;
		resetSoccerBall();
	}

	/**
	 * Get ball location
	 * @return Ball location
	 */
	public static SoccerBall getSoccerBall()
	{
		return soccerBall;
	}

	/**
	 * Move the ball
	 * @param initialDistance The initial distance
	 * @param initialVelocity The initial velocity
	 * @param acceleration The accelation
	 */
	public void moveBall(int initialDistance, double initialVelocity, double acceleration)
	{
		moveBallY(initialDistance);
		setVelocity(initialVelocity);
		Timer timer = new Timer();
		TimerTask repaintTask = new TimerTask()
		{
			@Override
			public void run()
			{
				if (Math.abs(velocity) < 2)
				{
					velocity = 0.0;
					timer.cancel();
				}
				else
				{
					velocity = velocity - acceleration;
				}
				moveBallY((int) velocity);
			}
		};
		timer.schedule(repaintTask, 0, 10);
	}

	/**
	 * Move by given distance on y direction
	 * @param distance The distance
	 */
	public void moveBallY(int distance)
	{
		if (getPosition().y + distance < 510 && getPosition().y - distance > 20)
		{
			setPosition(new Point(getPosition().x, getPosition().y - distance));
		}
		else
		{
			setVelocity(0.0);
		}
	}

	/**
	 * Reset the ball
	 */
	public void resetSoccerBall()
	{
		setVelocity(0.0);
		setPosition(new Point(480, 500));
	}

	/**
	 * Check whether on the goal keeper side
	 * @return true or false
	 */
	public boolean onGoalkeeperSide()
	{
		return getPosition().y < 200;
	}

	/**
	 * Check whether in gate
	 * @return true or false
	 */
	public boolean inGate()
	{
		return getPosition().x > 180 
				&& getPosition().x < 400
				&& getPosition().y > 10 
				&& getPosition().y < 60;
	}

	/**
	 * Set velocity
	 * @param velocity The velocity
	 */
	public void setVelocity(double velocity)
	{
		this.velocity = velocity;
	}

	/**
	 * Get position
	 * @return The position
	 */
	public Point getPosition()
	{
		return position;
	}

	/**
	 * Set position
	 * @param position The new position
	 */
	public void setPosition(Point position)
	{
		this.position = position;
	}

	/**
	 * Get color
	 * @return The color of the ball
	 */
	public Color getColor()
	{
		return color;
	}
}
