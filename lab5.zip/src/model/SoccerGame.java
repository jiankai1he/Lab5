package model;

import java.util.Timer;
import java.util.TimerTask;

import model.players.*;

/**
 * The soccer game class
 */
public class SoccerGame {
	//time remaining
	private Integer timeRemaining;
	//the goal
	private Integer goal;
	//whether paused
	private Boolean isPaused;
	//whether game is over
	private Boolean isOver;
	//the players
	private final PlayerCollection gamePlayers;

	/**
	 * The constructor
	 */
	public SoccerGame() {
		timeRemaining = 60;
		goal = 0;
		isPaused = false;
		isOver = false;
		SoccerBall.getSoccerBall().resetSoccerBall();
		PlayerFactory playerFactory = new PlayerFactory();
		gamePlayers = new PlayerCollection();
		gamePlayers.add(playerFactory.getPlayer("striker"));
		gamePlayers.add(playerFactory.getPlayer("goalkeeper"));
		startGame();
	}

	/**
	 * Start the game
	 */
	private void startGame() {
		Timer timer = new Timer();
		TimerTask timerTask = new TimerTask() {
			@Override
			public void run() {
				if (!isPaused()) {
					if (getTimeRemaining() <= 0) {
						setOver(true);
						timer.cancel();
					} else {
						setTimeRemaining(getTimeRemaining() - 1);
					}
					if (isScored()) {
						setPaused(true);
						setGoal(getGoal() + 1);
						getActivePlayer().setPlayerStatistics(getActivePlayer().getPlayerStatistics() + 1);
						getGamePlayers().get("Striker").setInitialPosition();
						SoccerBall.getSoccerBall().resetSoccerBall();
					} else {
						automateGoalkeeper();
					}
				}
			}
		};
		timer.schedule(timerTask, 1000, 1000);
	}

	/**
	 * Get the remaining time
	 * @return The remaing time
	 */
	public Integer getTimeRemaining() {
		return timeRemaining;
	}

	/**
	 * Set the remaining time
	 * @param timeRemaining The remaining time
	 */
	public void setTimeRemaining(Integer timeRemaining) {
		this.timeRemaining = timeRemaining;
	}

	/**
	 * Get the goal
	 * @return The goal
	 */
	public Integer getGoal() {
		return goal;
	}

	/**
	 * Set the goal
	 * @param newGoal The updated goal
	 */
	public void setGoal(Integer newGoal) {
		goal = newGoal;
	}

	/**
	 * Check whether paused
	 * @return Whether paused
	 */
	public Boolean isPaused() {
		return isPaused;
	}

	/**
	 * Set whether paused
	 * @param paused Whether paused
	 */
	public void setPaused(Boolean paused) {
		isPaused = paused;
	}

	/**
	 * Check whether game over
	 * @return Whether game over
	 */
	public Boolean isOver() {
		return isOver;
	}

	/**
	 * Set whether game over
	 * @param over Whether game over
	 */
	public void setOver(Boolean over) {
		isOver = over;
	}

	/**
	 * Get all players
	 * @return All players
	 */
	public PlayerCollection getGamePlayers() {
		return gamePlayers;
	}

	/**
	 * Move goal keeper
	 */
	public void automateGoalkeeper() {
		SoccerBall soccerBall = SoccerBall.getSoccerBall();
		Goalkeeper goalkeeper = (Goalkeeper) gamePlayers.get("Goalkeeper");
		if (soccerBall.onGoalkeeperSide()) {
			goalkeeper.grabsBall();
			goalkeeper.shootBall();
			goalkeeper.setPlayerStatistics(goalkeeper.getPlayerStatistics() + 1);
		} else {
			goalkeeper.moveRandomly();
		}
	}

	/**
	 * Whether the ball in gate
	 * @return true or false
	 */
	public boolean isScored() {
		return SoccerBall.getSoccerBall().inGate();
	}

	/**
	 * Get the striker
	 * @return The striker player
	 */
	public GamePlayer getActivePlayer() {
		return gamePlayers.get("Striker");
	}
}
