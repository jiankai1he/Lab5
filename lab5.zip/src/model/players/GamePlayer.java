package model.players;

import model.SoccerBall;

import java.awt.*;

/**
 * The GamePlayer class
 */
public abstract class GamePlayer implements Comparable<GamePlayer> {

	//player name
	protected final String playerName;
	//player color
	protected final Color playerColor;
	//player position
	protected Point playerPosition;
	//player statistics
	protected final PlayerStatistics playerStatistics;

	/**
	 * Constructor
	 * @param name The name of player
	 * @param color The color of player
	 */
	public GamePlayer(String name, Color color) {
		playerName = name;
		playerColor = color;
		playerStatistics = new PlayerStatistics();
		setInitialPosition();
	}

	/**
	 * Check whether the player has ball
	 * @return true or false
	 */
	public boolean isPlayerHasBall() {
		Point playerPositionCenter = new Point(getPlayerPosition().x + 15, getPlayerPosition().y + 30);
		return playerPositionCenter.distance(SoccerBall.getSoccerBall().getPosition()) < 55;
	}

	/**
	 * Take the ball
	 */
	public void grabsBall() {
		SoccerBall ball = SoccerBall.getSoccerBall();
		if (getPlayerPosition().x + 15 > ball.getPosition().x) {
			ball.setPosition(new Point(getPlayerPosition().x - 10, getPlayerPosition().y + 55));
		} else {
			ball.setPosition(new Point(getPlayerPosition().x + 20, getPlayerPosition().y + 55));
		}
	}

	/**
	 * Move left
	 */
	public abstract void moveLeft();

	/**
	 * Move right
	 */
	public abstract void moveRight();

	/**
	 * Move up
	 */
	public abstract void moveUp();

	/**
	 * Move down
	 */
	public abstract void moveDown();

	/**
	 * Shoot the ball
	 */
	public abstract void shootBall();

	/**
	 * Get the name
	 * @return The name of player
	 */
	public String getPlayerName() {
		return playerName;
	}

	/**
	 * Get the color
	 * @return The color of player
	 */
	public Color getPlayerColor() {
		return playerColor;
	}

	/**
	 * Get position
	 * @return The player position
	 */
	public Point getPlayerPosition() {
		return playerPosition;
	}

	/**
	 * Set initial position
	 */
	public abstract void setInitialPosition();

	/**
	 * Set position
	 * @param newPosition The new position
	 */
	public void setPlayerPosition(Point newPosition) {
		playerPosition = newPosition;
		if (isPlayerHasBall()) {
			grabsBall();
		}
	}

	/**
	 * Get player statistics
	 * @return The statistics of player
	 */
	public Integer getPlayerStatistics() {
		return playerStatistics.getStatistics();
	}

	/**
	 * Set player statistics
	 * @param newStatistics The updated statistics
	 */
	public void setPlayerStatistics(Integer newStatistics) {
		playerStatistics.setStatistics(newStatistics);
	}

	/**
	 * Compare two players
	 * @param otherPlayer The other player
	 * @return negative is <, 0 is ==, positive is >
	 */
	@Override
	public int compareTo(GamePlayer otherPlayer) {
		return otherPlayer.getPlayerStatistics().compareTo(this.getPlayerStatistics());
	}

	/**
	 * To string
	 * @return A string
	 */
	@Override
	public abstract String toString();
}
