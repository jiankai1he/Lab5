package model.players;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/**
 * Player collection class
 */
public class PlayerCollection implements Iterable<GamePlayer>
{
	//all the players
	private ArrayList<GamePlayer> players=new ArrayList<>();

	/**
	 * Add one player
	 * @param player A new player
	 */
	public void add(GamePlayer player)
	{
		players.add(player);
	}

	/**
	 * Get the player by name
	 * @param name The palyer name
	 * @return A player
	 */
	public GamePlayer get(String name)
	{
		for(int i=0;i<players.size();i++)
		{
			if(players.get(i).getPlayerName().equals(name)) return players.get(i);
		}
		return null;
	}

	/**
	 * Sort all players
	 */
	public void sort()
	{
		Collections.sort(players);
	}

	/**
	 * Get the iterator for all players
	 * @return A iterator for players
	 */
	@Override
	public Iterator<GamePlayer> iterator()
	{
		return new PlayerCollectionIterator(players);
	}
}
