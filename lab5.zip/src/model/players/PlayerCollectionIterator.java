package model.players;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Player collection iterator class
 */
public class PlayerCollectionIterator implements Iterator<GamePlayer>
{
	//all players
	private ArrayList<GamePlayer> players;
	//the index of visited player
	private int next;

	/**
	 * Constructor
	 * @param players All players
	 */
	public PlayerCollectionIterator(ArrayList<GamePlayer> players)
	{
		this.players=players;
		next=0;
	}

	/**
	 * Check whether has next player
	 * @return true or false
	 */
	@Override
	public boolean hasNext()
	{
		return next<players.size();
	}

	/**
	 * Get next player
	 * @return A player
	 */
	@Override
	public GamePlayer next()
	{
		next++;
		return players.get(next-1);
	}
}