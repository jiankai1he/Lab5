package model.players;

import java.awt.*;

/**
 * Player factory
 */
public class PlayerFactory
{
	/**
	 * Get one player by type
	 * @param type The type of player
	 * @return The player
	 */
	public GamePlayer getPlayer(String type)
	{
		if(type.equals("striker"))
		{
			return new Striker("Striker", Color.blue);
		}
		else if(type.equals("goalkeeper"))
		{
			return new Goalkeeper("Goalkeeper", Color.yellow);
		}
		else return null;
	}
}
