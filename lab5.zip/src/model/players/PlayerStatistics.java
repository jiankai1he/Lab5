package model.players;

/**
 * The statistics of the player
 */
public class PlayerStatistics
{
	//the score
	private int statistic;

	/**
	 * Get the score
	 * @return The score
	 */
	public int getStatistics()
	{
		return statistic;
	}

	/**
	 * Set the score
	 * @param statistic The new score
	 */
	public void setStatistics(int statistic)
	{
		this.statistic=statistic;
	}

	/**
	 * To string
	 * @return A string
	 */
	public String toString()
	{
		return ""+statistic;
	}
}
