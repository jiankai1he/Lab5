package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.Point;
import java.util.Iterator;

import org.junit.jupiter.api.Test;

import model.*;
import model.players.*;

class UnitTest
{

	@Test
	void testSoccerBall()
	{
		SoccerBall ball=SoccerBall.getSoccerBall();
		assertEquals(ball.getColor(), Color.white);
		//assertEquals(ball.getPosition(), new Point(480, 500));
		ball.moveBall(5, 0, 1.1);
		ball.moveBallY(5);
		assertEquals(ball.onGoalkeeperSide(), true);
		//assertEquals(ball.inGate(), false);
		ball.setVelocity(5);		
		ball.moveBall(0,  0.1,  0.1);
		ball.moveBall(0,  10,  10);
		ball.setPosition(new Point(0, 0));
		ball.moveBallY(50);
		ball.setPosition(new Point(0, 100));
		ball.moveBallY(50);
		ball.setPosition(new Point(0, 500));
		ball.moveBallY(50);
		ball.setPosition(new Point(0, 500));
		ball.moveBallY(500);
		ball.setPosition(new Point(250, 0));
		assertEquals(ball.onGoalkeeperSide(), true);
		ball.setPosition(new Point(150, 250));
		assertEquals(ball.onGoalkeeperSide(), false);
		ball.setPosition(new Point(150, 50));
		assertEquals(ball.inGate(), false);
		ball.setPosition(new Point(150, 80));
		assertEquals(ball.inGate(), false);
		ball.setPosition(new Point(200, 5));
		assertEquals(ball.inGate(), false);
		ball.setPosition(new Point(200, 50));
		assertEquals(ball.inGate(), true);
		ball.setPosition(new Point(200, 80));
		assertEquals(ball.inGate(), false);
		ball.setPosition(new Point(500, 5));
		assertEquals(ball.inGate(), false);
		ball.setPosition(new Point(500, 50));
		assertEquals(ball.inGate(), false);
		ball.setPosition(new Point(500, 80));
		assertEquals(ball.inGate(), false);
	}

	@Test
	void testSoccerGame()
	{
		SoccerGame game=new SoccerGame();
		game.setTimeRemaining(60);
		assertEquals(game.getTimeRemaining(), 60);
		game.setGoal(10);
		assertEquals(game.getGoal(), 10);
		game.setPaused(true);
		assertEquals(game.isPaused(), true);
		game.setOver(true);
		assertEquals(game.isOver(), true);
		Iterator<GamePlayer> ite=game.getGamePlayers().iterator();
		assertEquals(ite.hasNext(), true);
		ite.next();
		assertEquals(ite.hasNext(), true);
		ite.next();
		assertEquals(ite.hasNext(), false);
		assertEquals(game.isScored(), false);
		assertEquals(game.getActivePlayer().getPlayerName(), "Striker");
		game.automateGoalkeeper();
		game.setPaused(false);
		SoccerBall.getSoccerBall().setPosition(new Point(100, 100));
		game.automateGoalkeeper();
	}
	
	@Test
	void testGoalkeeper()
	{
		Goalkeeper k=new Goalkeeper("A", Color.red);
		k.moveDown();
		k.moveUp();
		k.moveLeft();
		k.moveRight();
		k.moveRandomly();
		assertEquals(k.toString(), "A caught 0 balls");
		k.setPlayerPosition(new Point(0,0));
		k.moveDown();
		k.moveLeft();
		k.setPlayerPosition(new Point(800,0));
		k.moveRight();
		k.moveUp();
		SoccerBall ball=SoccerBall.getSoccerBall();
		ball.setPosition(new Point(0, 0));
		k.moveRandomly();
		k.setPlayerPosition(new Point(800,800));
		k.moveDown();
		assertEquals(k.toString(), "A caught 0 balls");
	}
	
	@Test
	void testPlayerCollection()
	{
		PlayerCollection c=new PlayerCollection();
		Goalkeeper a=new Goalkeeper("A", Color.red);
		c.add(a);
		Striker b=new Striker("B", Color.black);
		c.add(b);
		PlayerFactory f=new PlayerFactory();
		GamePlayer a2=f.getPlayer("goalkeeper");
		f.getPlayer("");
		c.add(a2);
		c.sort();
		assertEquals(c.get("A"), a);
		assertEquals(c.get("B"), b);
		assertEquals(c.get("D"), null);
	}
	
	@Test
	void testStriker()
	{
		Striker k=new Striker("A", Color.red);
		k.moveDown();
		k.moveUp();
		k.moveLeft();
		k.moveRight();
		assertEquals(k.toString(), "A scored 0 goals");
		k.setPlayerPosition(new Point(0,0));
		k.moveDown();
		k.moveLeft();
		k.setPlayerPosition(new Point(800,0));
		k.moveRight();
		k.moveUp();
		k.setPlayerPosition(new Point(800,800));
		k.moveDown();
		k.shootBall();
		SoccerBall ball=SoccerBall.getSoccerBall();
		ball.setPosition(new Point(50, 50));
		k.setPlayerPosition(new Point(100, 100));
		k.grabsBall();
		ball.setPosition(new Point(500, 500));
		k.setPlayerPosition(new Point(100, 100));
		k.grabsBall();
		assertEquals(k.getPlayerColor(), Color.red);
		assertEquals(k.toString(), "A scored 0 goals");
	}
}
